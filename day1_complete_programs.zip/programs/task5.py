'''
write a program to capture 2 numbers from the keyboard and display its sum


Enter first number : 10
Enter second number: 20

Total : 30
'''


first = int(input("Enter first number   :"))
second = int(input("Enter second number :"))

total = first + second

print("Sum of the numbers :", total)