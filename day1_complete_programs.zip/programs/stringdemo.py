name = "python programming"
                  
#string[start:stop:step]
print(name)
print(name[0]) #p
print(name[1]) #y
print(name[0:10])
print(name[1:5])
print(name[:])   #evreything
print(name[0:17:2])
print(name[1:17:2])
print(name[::])  #everything
print(name[-4:-1]) #min
print(name[::-1])  # reverse the string


alist =[10,20,30,40,50,60,70]
print(alist[0])
print(alist[0:8:2])
print(alist[1:8:2])
print(alist[::-1])