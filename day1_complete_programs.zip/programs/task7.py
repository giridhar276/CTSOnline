'''
define two lists
alist = [10,20,30,40,50,10]
blist = [40,50,60,70,80]

display all the UNIQUE elements of both alist and blist
display all the COMMON elements of both alist and blist
'''

alist = [10,20,30,40,50,10]
blist = [40,50,60,70,80]

aset = set(alist)
bset = set(blist)

print(list(aset.union(bset)))
print(list(aset.intersection(bset)))
