

filename = "perl,python,unix,java,hadoop"
output = filename.split(",")
print(output)


file = input("Enter any filename :")
print("you entered :",file)
# converting to list
data = file.split(".")
print("filename :", data[0])
print("extension:", data[1])
