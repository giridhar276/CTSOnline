 
# set

aset = {10,10,10,20,30}
bset = {30,40,50}
print(len(aset))
aset.add(90)
aset.add(10)  
#print(aset[0])

print(aset)
print(bset)

print(aset.union(bset))  #OR
print(aset | bset)


print(aset.intersection(bset)) #OR
print(aset & bset)


print(aset.difference(bset))  #OR
print(aset - bset)

print(aset.issubset(bset))
print(aset.issuperset(bset))

 