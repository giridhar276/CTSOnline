##### simple if
a,b =10,20
if a<b:
    print("A is less than B")
    
# if-else    
a,b =10,20
if a<b:
    print("A is less than B")
else:
    print("B is less than A")


name = "python"
if name.isupper():
    print("string is upper")
else:
    print("string is lower")
    
    
# if-elif-elif.....else    
color = input("Enter any color :")    
if color == "red":
    print("you entered red")
elif color == "black":
    print("you entered black")
elif color =="green":
    print("you entered greetn")
else:
    print("uknown color")
    