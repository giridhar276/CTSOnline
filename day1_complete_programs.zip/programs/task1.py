'''
write a program to capture any filename from the keyboard and display its filename and extension seperately

Output:

Enter any filename:  abc.py

filename : abc
extension: py
'''

filename = input("Enter any filename :")

print("File name :", filename.split(".")[0])
print("Extension :", filename.split(".")[1])

'''
write  a program to capture some delimeted string from the keyboard and split the string with comma and display the length after splitting.

Output:
Enter any delimited string :  python,perl,unix,scala,spark

List elements are : [ 'python' , 'perl', 'unix','scala' , 'spark' ]
Length of the list  : 5
'''
alist = input("Enter any delimited string :")
data = alist.split(",")
print("list elements are :", data )
print("length of the list:", len(data))



