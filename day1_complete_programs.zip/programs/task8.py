
'''
define a string as below

lang = "perl,unix,hadoop,scala,spark,ruby,go"

write a program to check whether 'python' is existing in the string or not.
'''

#method1
lang = "perl,unix,hadoop,scala,spark,ruby,go"
if 'python' in lang:
    print("exists")
else:
    print("doesn't exist")
    
#method2
lang = "perl,unix,hadoop,scala,spark,ruby,go"
getcount = lang.count('python')
if getcount > 0 :
    print("exists")
else:
    print('doesnt exist')


#method3 :
lang = "perl,unix,hadoop,scala,spark,ruby,go"
if lang.find('python')> 0:
    print("exists")
else:
    print('doesnt exist')
    
