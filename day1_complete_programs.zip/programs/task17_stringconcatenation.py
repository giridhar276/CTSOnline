'''
define some list as below

alist = ["google","oracle","microsoft"]

write a program to
add "http://www"  at the beginning and  
add ".com" at tht end of the string

Output:
http://www.google.com
http://www/.oracle.com
http://www.microsoft.com
'''


alist = ["google","oracle","microsoft"]

for item in alist:
    print("http://www."  + item + ".com")