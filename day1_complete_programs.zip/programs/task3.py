'''
write a program for performing the below operaitons

1. define empty tuple
2. append  "unix" to the tuple
3. append few more elements like 'spark', 'scala','hadoop',sccm' to the list
4  append few more elements like 'c','cpp','java','salesforce','sap','unix' to the list
5.  remove java
6  remove salesforce -
7. add  'oracle' at the index 0
8. add ' mongodb' at the index 5
9. reverse all the elements
10. display the total.  no. of eleents of the list
11. display the total count of 'unix' in the list
'''

atup = ()
alist = list(atup)
alist.append('unix')
print("After appending :", alist)
alist.extend(['spark', 'scala','hadoop','sccm'])
print("After extending :", alist)
alist.extend(['c','cpp','java','salesforce','sap','unix'])
print("After extending :", alist)
if 'java' in alist:
    alist.remove('java')
    
alist.insert(0,'oracle')    
alist.insert(5,'mongodb')
print("After inserting :", alist)

alist.reverse()
print("Afterreversing :",alist)

print("total no. of elments :", len(alist))

print("total count of unix :", alist.count('unix'))

