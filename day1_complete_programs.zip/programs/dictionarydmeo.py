adict = {"chap1":10 ,"chap2":20,"chap3":30}
print(adict)
# adding key-value pairs
adict["chap4"] = 40
adict["chap5"] = 50

print(len(adict))

print(adict)
# display ONLY keys
print(adict.keys())
# display ONLY values
print(adict.values())
# display key-value items
print(adict.items())

#print(adict["chap8"])
print(adict.get("chap1"))

bdict = {"chap11":110 ,"chap12":120}
adict.update(bdict)  #     all the elements of bdict to adict
print(adict)

adict.pop("chap1")   # will remote chap1-10 from dictionary
print(adict)
adict.popitem()      # will remove random key-value pair
print(adict)

adict.setdefault("chap13",130) #will create new key-value to the dictionary
print(adict)

adict.setdefault("chap3",300)
print(adict)