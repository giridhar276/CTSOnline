'''
write a program to capture any string from the keyboard and perform the below

if the string is defined in uppercase......   convert the string to lower and display it

if the string is defined in lowercase ...... convert the string to upper and display it.

'''

string = input("Enter any string :")

if string.isupper():
    print(string.lower())
    
if string.islower():
    print(string.upper())    
    
    
# 2nd method
string = input("Enter any string :")
print(string.swapcase())    
