
for val in range(50,1,-1):
    print(val)
    
    
print("-------------")    
for val in range(1,10)    :
    print(val)
    
print("-------------")    

for val in range(2,10,2)    :
    print(val)

print("-------------")    

for val in range(1,10,2)    :
    print(val)    