
# list
alist = [10,20,30]
print("list elements are :", alist)
print("1st element is  :", alist[0]) #10
#trying to replace value at index 0
alist[0] = 1000
print("After modifying :",alist)


#tuple
atup = ("unix","hadoop","scala")
print("tuple elements are :", atup)
#trying to replace value at index 0
#atup[0] = 'SAS'
print("After modifying :", atup)

# converting tuple to the list
alist = list(atup)
alist[0] = 'SAS'
# reconverting back to tuple
atup = tuple(alist)
print("After modifying :", atup)
print("first element :", atup[0])