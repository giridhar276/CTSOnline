
atup = (10,20,30)
print(len(atup))

getcount = atup.count(10)
print(getcount)

print(atup.index(30))