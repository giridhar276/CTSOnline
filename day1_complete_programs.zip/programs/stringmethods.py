
name = "python programming"
print(len(name))
print(name.upper())
print(name.lower())
print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.count('p'))
print(name.count('z'))
print(name.split(" "))
print(name.split("r"))
print(name.replace("python","ruby"))
print(name.capitalize())
#will remove the white spaces at both the ends
aname  = " python "
print(aname.strip())

bname = "I love {} and {}"
print(bname.format("python","scala"))
print(bname.format('hadoop','java'))
# aligning python in 10 spaces width and next java
print("python".ljust(10),"java")

 