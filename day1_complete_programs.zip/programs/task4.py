'''
define tuple as below
numbers = (10,20,10,20,30,40,60,70)

write a program to remove all the duplicates of the tuple
'''

numbers = (10,20,10,20,30,40,60,70)
print(tuple(set(numbers)))