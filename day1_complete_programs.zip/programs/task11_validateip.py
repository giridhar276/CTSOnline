'''
write a program to validate the IP address

Enter any IP address : 192.168.0.1
Its valid IP
Enter any IP address : 1001.1.2.3
Invalid IP
'''

ip = input("Enter IP address :")
print("you entered :",ip)

data = ip.split(".")
#['127','0','0','1']
# syntax :  map(function,list)
data = list(map(int,data))  # map() will convert each element of list ------------> integer
#[127,0,0,1]

if len(data) ==4 :
    if data[0] in range(1,256) and data[1] in range(0,256) and data[2]  in range(0,256) and data[3] in range(0,256):
        print("Valid ip")
    else:
        print("INvalid ip")
else:
    print("Invalid IP")        