


filename = input("Enter any filename :")
print("Filename is :", filename)