
import os
for val in range(1,11):
    os.rmdir("dir" + str(val))