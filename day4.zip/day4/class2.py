

class Employee:
    def getEmployee(self,name):
        #local varaibles
        self.name = name
        
    def displayEmployee(self)   :
        print("Employee name is :",self.name)
        
#object creation
emp1 = Employee()
emp1.getEmployee('Ram')
emp1.displayEmployee()


emp2 = Employee()
emp2.getEmployee('Rita')
emp2.displayEmployee()
