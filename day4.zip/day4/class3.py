
class Employee:
    def __init__(self,name):
        #local varaibles
        self.name = name
        
    def displayEmployee(self)   :
        print("Employee name is :",self.name)
        
#object creation
emp1 = Employee('Ram')
emp1.displayEmployee()


emp2 = Employee('Rita')
emp2.displayEmployee()

#constructor in java starts with the
# class name

#constructor in Python starts with the
# __init__()

# Constructor is invoked automatically
# when the object is invoked

# In general.. constructor is used to
# initialize the values
