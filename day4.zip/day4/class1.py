
class Employee:
    def displayEmployee(self,name,age):
        #local varaibles
        self.name = name
        self.age = age
        print("Employee name is :",self.name)
        print("Employee age is  :", self.age)
        
        
#object creation
emp1 = Employee()
emp1.displayEmployee('Ram',29)  


emp2 = Employee()
emp2.displayEmployee('Rita',20)

emp3 = Employee()
emp3.displayEmployee('Rao',50)

emp4 = Employee()
emp4.displayEmployee('Singh',15)