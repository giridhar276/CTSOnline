import pandas as pd

df = pd.read_csv("realestate.csv")
print(df)