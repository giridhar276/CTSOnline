class employee:
    def displayemployee(self,name):
        #local variables
        self.name = name
    def displayemployee(self) :
        print("employee name is :",self.name)

#####object
emp1 = employee()
emp1.displayemployee('ram')
emp1.displayemployee)
emp2 = employee()
emp2.displayemployee('rita')
emp2.displayemployee()
