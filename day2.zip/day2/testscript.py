import json
with open("example_2.json") as fr:
    data = json.load(fr)
    for key,value in data.items():
        for subkey,subval in value.items():

            if key=='maths':
                for sskey,ssval in subval.items():
                    print(sskey,ssval)