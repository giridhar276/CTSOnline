from openpyxl import Workbook
wb = Workbook()
ws = wb.active
with open("numbers.txt","r") as fr :
    for line in fr:
        #remove white spaces at the end of string
        line = line.strip()
        print(line)
        output = line.split(",")
        ws.append(output)
wb.save("demoexample.xlsx")        