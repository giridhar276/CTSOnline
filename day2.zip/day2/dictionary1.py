'''
define dictionary as below

infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":50} }

write a program to display the below output

state literacy rate
------  ---------------
ap       70
tn        75
up       50
'''

infodoc =  { 2001: {"ap":70}  , 2002:{"tn":75} , 2003:{"up":90} , 2004 : {'madhyapradesh' :79} }
print("state".ljust(10), "literacy rate")
print("--------------------")
for key,value in infodoc.items():
    for subkey,subvalue in value.items():
        print(subkey.ljust(15),subvalue)