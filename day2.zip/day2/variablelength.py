# variable length arguments
# If any object is prefixed with * .. tuple
# If any object is prefixed with ** .. dictionary
def display(*info):
    for val in info:
        print(val)
display(10,20,30,40,50,60,43,43,54)


def displayInfo(**data):
    for key,value in data.items():
        print(key,value)
displayInfo(chap1 =10 ,chap2=20)
