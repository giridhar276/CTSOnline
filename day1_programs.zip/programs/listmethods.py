# list methods
alist = [10,20,30,40,50]
print(len(alist))
alist.append(600)
alist.append(1)
print("After appending :", alist)

alist.extend([45,43,64,575,23])
print("After extending :", alist)
# to get the no. of occurences of 10 in the list
getcount = alist.count(10)
print(getcount)

print("index of 20 is  :", alist.index(20))

# list.insert(where to insert,what to insert)
alist.insert(0,5)
alist.insert(5,67)
print("After inserting :", alist)

alist.pop()   # will remove the last element by default
print("After pop :",alist)

alist.pop(2)  # will remove the value at index 2
print("After pop :",alist)

alist.remove(50) # value 50 will be removed  # here indexing is not used
print("After remove :", alist)

alist.reverse()
print("after reversing :", alist)

alist.sort()
print("after sorting :", alist)