#a class inherit from two classes
class Father():
    def skills(self):
        print("gardening,programming")

class Mother():
    def skills(self):
        print("cooking,art")

#a class inherit from two classes
class Child(Father,Mother):
    def skills(self):
        print("sprots")
        
c=Child()
c.skills()
#sports


#a class inherit from two classes
class Child2(Father,Mother):
    def skills(self):
        Father.skills(self)
        Mother.skills(self)
        print("sprots")

c=Child2()
c.skills()
#gardening,programming
#cooking,art
#sports