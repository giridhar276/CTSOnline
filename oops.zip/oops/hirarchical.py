'''
--what is inheritance?
the object of the subclasses (derived classes) can call the method and property from the parent class
For example, car class and motor cycle class are classes that inherit from vehicle class or we can say that car class and motor cycle class
are subclasses of vehicle class because they share same property and method with vehicle class.

--benefit
1) code reuse: reuse the code from parent class but at the same time you can customize your own class
2) extensibility
3) readability
'''







 
#--------------------------------------------------------------------------------------------------------
class vehicle():
    def __init__(self,price,gas,color):
        self.price = price
        self.gas = gas
        self.color =color
        
    def fillUpTank(self):
        self.gas=100
    
    def emptyTank(self):
        self.gas=0
        
    def gasLeft(self):
        return self.gas
        
class car(vehicle):
    def __init__(self,price,gas,color,speed):
        super.__init(price,gas,color)
        self.speed=speed
     
    def beep(self):
        print("Beep Beep")
        
    
class truck(vehicle):
    def __init__(self,price,gas,color,tires):
        super().__init__(price,gas,color,tires)
        self.tires = tires
    
    def beep(self):
        print("Honk Honk")