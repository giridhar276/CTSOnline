class dog():
    def __init__(self,name,age):
        self.name=name
        self.age=age
    
    def speak(self):
        print("Hi I am",self.name, "and I am",self.age,"years old.")
        
    def talk(self):
        print("bark!")

#dog will be the parent class of cat children class
class cat(dog):
    
    def __init__(self,name,age,color):
        #the super() automatically exercute the init method in dog class
        super().__init__(name,age)
        self.color = color

    def talk(self):
        print("Meow!")

tim = cat("tim",5,"blue")

#--instead of printing "bark" it prints "meow" 
#--the method has the same name with the parent class method will overwrite the inherited method 
tim.talk() 
