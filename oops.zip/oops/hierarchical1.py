class Vehicle:
    def general_usage(self):
        print("general use: transportation")
        
class Car(Vehicle): #here the syntex means the car class is derived from vehicle class
    def __init__(self):
        print("I'm car")
        self.wheels=4
        self.has_roof=True
    
    def specific_usage(self):
        print("specific use: commute to work, vacation with family")
     
class MotorCycle(Vehicle):
    def __init__(self):
        print("I'm motor cycle")
        self.wheel=2
        self.roof=False
        
    def specific_usuage(self):
        self.general_usuage()
        print("specific use: road trip, racing")
        
#create car and motor cycle object
c = Car()  
#I'm car

c.specific_usage() 
#specific use: commute to work, vacation with family

#we can use the method from parent class
c.general_usage()  
#general use: transportation
